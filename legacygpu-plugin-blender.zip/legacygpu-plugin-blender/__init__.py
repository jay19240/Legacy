bl_info = {
  "name": "Legacy Exporter",
  "author": "panzer-banana",
  "version": (1, 0, 0),
  "blender": (4, 2, 0),
  "location": "View3D > Properties > Legacy Export",
  "description": "Export to a custom Legacy format",
  "category": "Import-Export"
}

# Imports --------------------------------------------------------------------------
from . import operators
from . import operators_world
from . import panels
from . import functions
from . import props
from . import utils
import bpy
import os
from bpy.app.handlers import persistent
# ----------------------------------------------------------------------------------

_handle = None
addon_keymaps = []

def register():
  global _handle

  props.register()
  operators.register()
  operators_world.register()
  panels.register()

  wm = bpy.context.window_manager
  kc = wm.keyconfigs.addon
  if kc:
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new("object.export_pack", 'E', 'PRESS', ctrl=True)
    addon_keymaps.append((km, kmi))
  #endif

  _handle = bpy.types.SpaceView3D.draw_handler_add(
    utils.draw_grf_node_values, (None, bpy.context), 'WINDOW', 'POST_PIXEL'
  )

def unregister():
  for km, kmi in addon_keymaps:
    km.keymap_items.remove(kmi)
  #endfor
  addon_keymaps.clear()

  props.unregister()
  operators.unregister()
  operators_world.unregister()
  panels.unregister()

if __name__ == "__main__":
  register()